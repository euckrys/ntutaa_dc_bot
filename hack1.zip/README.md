# ntutaa_dc_bot

This discord bot was created for the 2023 NTUTAA Orientation Camp.

Please change the "Token" to your own to ensure it works properly.
